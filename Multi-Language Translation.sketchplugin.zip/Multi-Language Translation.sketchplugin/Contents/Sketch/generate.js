@import 'utils.js'

function generateLanguageFile(doc) {
	var languageKeys = getLanguageKeys();
	var generateString = generateLanguageString(languageKeys);
	saveToLanguageFile(generateString, doc);
	alert("Generate language file", "Success");
}

function generateLanguageString(languageKeys) {
	var localeObject = {};
	var keysArray = [];
	for (var keyIndex = 0; keyIndex < languageKeys.length; keyIndex++) {
		var key = languageKeys[keyIndex];
		keysArray.push(unescape(key));
	}
	localeObject["keys"] = keysArray;

	var sketch = require('sketch');
	var document = sketch.getSelectedDocument();
	var allLayers = document.pages.flatMap(page => page.layers);

	var localObjectAdded = generateLayers(allLayers, localeObject, languageKeys);

	return JSON.stringify(localObjectAdded, undefined, 2);
}



function saveToLanguageFile(string, currentDocument) {
	var translationFileURL = [[[currentDocument fileURL] URLByDeletingPathExtension] URLByAppendingPathExtension:@"json"];
	var saveFilePath = [translationFileURL path];
	var saveString = NSString.stringWithString(string + "");
	saveString.writeToFile_atomically_encoding_error(saveFilePath,
		true,
		NSUTF8StringEncoding,
		null);
}

function addSelectionsToFile(context, filePath) {
	var currentString = NSString.stringWithContentsOfFile_encoding_error(filePath, NSUTF8StringEncoding, null);
	var localeObject = JSON.parse(currentString.toString());
	var languageKeys = localeObject["keys"];

	var sketch = require('sketch');
	var document = sketch.getSelectedDocument();
	var selectedLayers = document.selectedLayers;

	var localObjectAdded = generateLayers(selectedLayers, localeObject, languageKeys);

	saveToLanguageFile(JSON.stringify(localObjectAdded, undefined, 2), context.document);
}

function generateAndAddToFile(context) {
	var languageKeys = getLanguageKeys();
	var localeObject = {};

	var keysArray = [];
	for (var keyIndex = 0; keyIndex < languageKeys.length; keyIndex++) {
		var key = languageKeys[keyIndex];
		keysArray.push(unescape(key));
	}
	localeObject["keys"] = keysArray;

	var sketch = require('sketch');
	var document = sketch.getSelectedDocument();
	var selectedLayers = document.selectedLayers;

	var localObjectAdded = generateLayers(selectedLayers, localeObject, languageKeys);

	saveToLanguageFile(JSON.stringify(localObjectAdded, undefined, 2), context.document);
}

function getLanguageKeys() {
	var inputKeyContainerView = [[NSView alloc] initWithFrame: NSMakeRect(0, 0, 200, 25)];
	var textField = [[NSTextField alloc] initWithFrame: NSMakeRect(0, 0, 200, 25)];

	[inputKeyContainerView addSubview: textField];

	var alertDialog = [[NSAlert alloc] init];
	[alertDialog addButtonWithTitle: "OK"];
	[alertDialog setMessageText: "Enter language keys. Example for your input: en,de,fr,it"];
	[alertDialog setAlertStyle: NSWarningAlertStyle];
	[alertDialog setAccessoryView: inputKeyContainerView]
	if ([alertDialog runModal] == NSAlertFirstButtonReturn) {
		var languageKeys = [[textField stringValue] componentsSeparatedByString: ","];
		return languageKeys;
	}
}

function generateLayers(layers, localeObject, languageKeys) {
	var layersCount = (layers == undefined) ? 0 : layers.length;
	if (layersCount > 0) {
		layers.forEach(function (layer) {
			if (isSymbol(layer)) {
				console.log("Symbol to be translated detected: " + layer.name);
				generateSymbolLayer(layer, localeObject, languageKeys);
			} else if (isText(layer)) {
				console.log("Text to be translated detected: " + layer.name);
				generateTextLayer(layer, localeObject, languageKeys);
			} else if (isSymbolMaster(layer)) {
				console.log("Symbol Master detected (" + layer.name + "). Dive into next level.");
				generateLayers(layer.layers, localeObject, languageKeys);
			} else {
				console.log("Layer won't be translated: " + layer.name + " (" + (layer.type) + ")");
			}
		})
	} else {
		alert("Notification", "Please choose some layers!");
	}

	return localeObject;
}

function generateTextLayer(text, localeObject, languageKeys) {
	var localeKey = unescape(text.id);
	if (!localeObject[localeKey]) {
		localeObject[localeKey] = setLocaleObject(text.text, languageKeys);
	}
	setMetaObject(text, localeObject[localeKey]);
}

function generateSymbolLayer(symbol, localeObject, languageKeys) {
	var overrides = symbol.overrides;
	overrides.forEach(function (override) {
		if (isTranlatableSymbolOverride(override)) {
			var localeKey = unescape(override.id);
			if (!localeObject[localeKey]) {
				localeObject[localeKey] = setLocaleObject(override.value, languageKeys);
			}
			setMetaObject(symbol, localeObject[localeKey]);
		}
	});
}

function setLocaleObject(stringValue, languageKeys) {
	var contentObject = {};
	for (var keyIndex = 0; keyIndex < languageKeys.length; keyIndex++) {
		var key = languageKeys[keyIndex];
		contentObject[key] = unescape(stringValue);
	}

	var localizeObject = {};
	localizeObject["locale"] = contentObject;
	return localizeObject;
}

function setMetaObject(layer, localeObject) {
	localeObject["name"] = layer.name;
	localeObject["type"] = layer.type;
}