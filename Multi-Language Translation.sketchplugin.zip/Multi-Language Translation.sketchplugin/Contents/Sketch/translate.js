@import 'utils.js'

function translatePage(context, filePath) {
	var currentString = NSString.stringWithContentsOfFile_encoding_error(filePath, NSUTF8StringEncoding, null);
	var currentJsonObject = JSON.parse(currentString.toString());
	var keys = currentJsonObject["keys"];

	var comboBoxContainer = [[NSView alloc] initWithFrame: NSMakeRect(0, 0, 200, 25)];
	var comboxBox = [[NSPopUpButton alloc] initWithFrame: NSMakeRect(0, 0, 200, 25)];
	[comboxBox addItemsWithTitles: keys];
	[comboxBox selectItemAtIndex: 0];
	[comboBoxContainer addSubview: comboxBox];

	var languageDialog = [[NSAlert alloc] init];
	[languageDialog setMessageText: "Select language to translate"];
	[languageDialog addButtonWithTitle: 'OK']
	[languageDialog addButtonWithTitle: 'Cancel']
	[languageDialog setAccessoryView: comboBoxContainer]

	if ([languageDialog runModal] == NSAlertFirstButtonReturn) {
		var keyIndex = [comboxBox indexOfSelectedItem];

		var sketch = require('sketch');
		var document = sketch.getSelectedDocument();
		var currentPage = document.selectedPage;
		var layers = currentPage.layers;

		translateLayers(layers, currentJsonObject, keys[keyIndex]);

		alert("Translate", "Completed!");
	}
}

function translateLayers(layers, jsonObject, languageKey) {
	layers.forEach(function(layer) {
		if (isSymbol(layer)) {
			translateSymbol(layer, jsonObject, languageKey);
		} else if (isText(layer)) {
			translateText(layer, jsonObject, languageKey);
		} else {
			var childlen = layer.layers == undefined ? 0 : layer.layers.length;
			if (childlen > 0) {
				translateLayers(layer.layers, jsonObject, languageKey);
			}
		}
	});
}

function translateSymbol(symbol, jsonObject, languageKey) {
	var overrides = symbol.overrides;
	overrides.forEach(function (override) {
		var localeKey = unescape(override.id);
		var translation = getTranslation(localeKey, jsonObject, languageKey);
		if (translation) {
			override.value = translation;
		}
	});
}

function translateText(text, jsonObject, languageKey) {
	var localeKey = unescape(text.id);
	var translation = getTranslation(localeKey, jsonObject, languageKey);
	if (translation) {
		text.text = translation;
		text.adjustToFit();
	}
}

function getTranslation(key, jsonObject, languageKey) {
	if (jsonObject[key]) {
		var keyObject = jsonObject[key]
		if (keyObject["locale"]) {
			var localeObject = keyObject["locale"];
			if (localeObject[languageKey]) {
				var localeValue = localeObject[languageKey];
				console.log("Translate value '" + localeValue + "' to " + key);
				return localeValue;
			} else {
				console.log("Language not found: " + languageKey);
				return undefined;
			}
		} else {
			console.log("Locale node not found: " + key + "[locale]")
			return undefined;
		}
	} else {
		console.log("Key not found: " + key)
		return undefined;
	}
}