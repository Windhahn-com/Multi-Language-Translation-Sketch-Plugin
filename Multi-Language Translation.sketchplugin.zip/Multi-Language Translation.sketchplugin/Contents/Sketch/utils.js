function alert(title, message){
  var app = [NSApplication sharedApplication];
  [app displayDialog:message withTitle:title];
}

function isText(layer) {
  return (layer.type === "Text")
}

function isSymbol(layer) {
  return (layer.type === "SymbolInstance");
}

function isSymbolMaster(layer) {
  return (layer.type == "SymbolMaster");
}

function isNeedTranslate(layer) {
  var layerName = layer.name;
  return (layerName.indexOf("o_") == 0);
}

function isNested(symbol) {
  var symbolProperty = symbol.property;
  return (symbolProperty == "symbolID");
}

function isTranlatableSymbolOverride(symbol) {
  var symbolProperty = symbol.property;
  return (symbolProperty == "stringValue");
}

function isExistFilePath(filePath){
  var fileManager = [NSFileManager defaultManager];
  return [fileManager fileExistsAtPath:filePath];
}
